import React, {useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import EmployeeService from '../services/EmployeeService'
import * as XLSX from "xlsx";

const ListEmployeeComponent = () => {
    

    const [employees, setEmployees] = useState([])

    useEffect(() => {

        getAllEmployees();
    }, [])

    const getAllEmployees = () => {
        EmployeeService.getAllEmployees().then((response) => {
            setEmployees(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })
    }

    const deleteEmployee = (employee_id) => {
       EmployeeService.deleteEmployee(employee_id).then((response) =>{
        getAllEmployees()
        console.log(response.data);

       }).catch(error =>{
           console.log(error);
       })
        
    }

//fetch data from excel-sheet
    const readExcel = (file) => {
        const promise = new Promise((resolve, reject) => {
          const fileReader = new FileReader();
          fileReader.readAsArrayBuffer(file);
    
          fileReader.onload = (e) => {
            const bufferArray = e.target.result;
    
            const wb = XLSX.read(bufferArray, { type: "buffer" });
    
            const wsname = wb.SheetNames[0];
    
            const ws = wb.Sheets[wsname];
    
            const data = XLSX.utils.sheet_to_json(ws);
    
            resolve(data);
          };
    
          fileReader.onerror = (error) => {
            reject(error);
          };
        });
    
        promise.then((employee) => {
          console.log(employee);
          setEmployees(employee);
         
        });
      };

//Upload data from excel to database
      const uploadHandler = (e) => {
        e.preventDefault();
             console.log(employees)
        EmployeeService.uploadEmployee(employees).then((response)=>{
                console.log(response.data)

        }).catch(error => {
            console.log(error)
            
        })
    
    
    }    



    return (
        <div className = "container">
            <h2 className = "text-center" style = {{marginTop:"20px",marginBottom:"20px"}}> EMPLOYEE DETAILS </h2>
            <Link to = "/add-employee" className = "btn btn-primary mb-3"> ADD EMPLOYEE </Link>
            <button className='btn btn-success btn-sm' style ={{marginLeft:"880px",marginBottom:"50px"}} onClick = {(e) => uploadHandler(e)}>UPLOAD</button>
            <h6 style = {{marginLeft:"825px", marginTop:"-75px"}}>Add from excel sheet</h6>
            <input
                className = "btn btn-primary mb-3 btn-sm" style = {{marginLeft:"827px", marginTop:"1px",padding:"1px"}}
                type="file"
                onChange={(e) => {
                const file = e.target.files[0];
                readExcel(file);
                }}
            />
            <table className="table table-bordered table-striped table-sm ">
                <thead className = "text-center">
                            <th>Employee Id</th>
                            <th>Employee Name </th>
                            <th>Employee Status </th>
                            <th>Designation </th>
                            <th>Base Location </th>
                            <th>Company Name </th>
                            <th>Manager Name </th>
                            <th>Start Date </th>
                            <th>End Date </th>
                            <th>Actions</th>
                </thead>
                <tbody className = "text-center">
                    {
                        employees.map(
                            employee =>
                            <tr key = {employee.id}> 
                                <td>{employee.employee_id}</td>
                                <td>{employee.employee_name}</td>
                                <td>{employee.employee_status}</td>
                                <td>{employee.designation}</td>
                                <td>{employee.base_location}</td>
                                <td>{employee.company_name}</td>
                                <td>{employee.manager_name}</td>
                                <td>{employee.startDate}</td>
                                <td>{employee.endDate}</td>
                                <td>
                                  <Link className="btn btn-info btn-sm " style = {{marginLeft:"4px" ,marginBottom:"2px",padding:"1px"}} to={`/edit-employee/${employee.employee_id}`}>UPDATE</Link>
                                    <br></br><button className = "btn btn-danger btn-sm " onClick = {() => deleteEmployee(employee.employee_id)}
                                    style = {{marginLeft:"4px",padding:"3px"}}> DELETE</button>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    )
}

export default ListEmployeeComponent;