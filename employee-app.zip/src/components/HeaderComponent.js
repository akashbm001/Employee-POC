import React from 'react'

const HeaderComponent = () => {
    return (
        <div >
            <h4 className = "text-center bg-dark" style = {{color:'silver' }} >
                       
                            EMPLOYEE POC APPLICTION
           
            </h4>
        </div>
    )
}

export default HeaderComponent;